package com.company;

import dd.dedd;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
public class Main{
    public static void main(String[] args) {
        Log log = LogFactory.getLog(Main.class);
        log.info("start...");
        log.warn("end.");
	// write your code
        // 变量使用驼峰命名，首字母小写
        // 基本类型
        byte i = 127;
        short xx = 23344;
        long xxx = 22222;
        int x = 100;
        float s = 2.24f;
        double ss = 3.14;
        boolean d = true;
        boolean dd = false;
        char c = '你';
        //  引用类型
        String xt = "熊涛";
        String xd = """
                ni
                ked
                """;
        int[] in_5 = new int[5];
        int [] in_6 = new int[] { 1,3,4,4,5,6};
        // 常量， 赋值即终值,变量名大写
        final int FI = 100;
        //  var, 语法糖
        dedd.dedd('地');
        System.out.println(in_6[2]);

        // 继承
        Student xt_st = new Student("熊涛", 20, 20);
        System.out.println();
    }
}

class Person {
    protected String name;
    protected int age;
    public Person (String name,int age) {
      this.name = name;
      this.age = age;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}

class Student extends  Person
{
    public  Student (String name, int age, int id) {
        super(name,age);
    }

    public int findVar () {
        return super.age;
    }


    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public String getName() {
        return "傻傻";
    }
}
