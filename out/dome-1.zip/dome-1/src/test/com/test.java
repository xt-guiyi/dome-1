package test.com;

public class test {
    public static void text(char args) {
        System.out.println(args);
    }
}
