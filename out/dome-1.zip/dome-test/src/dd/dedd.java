package dd;

public class dedd {
    public static void dedd(char args) {
        System.out.println("ddddde");
    }
}
