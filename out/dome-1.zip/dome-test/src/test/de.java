package test;

public class de {
    public static void de(char args) {
        System.out.println('f');
    }
}
